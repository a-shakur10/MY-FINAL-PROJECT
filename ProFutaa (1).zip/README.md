# ProFutaa

Full-stack scouting platform for Kenyan footballers.
